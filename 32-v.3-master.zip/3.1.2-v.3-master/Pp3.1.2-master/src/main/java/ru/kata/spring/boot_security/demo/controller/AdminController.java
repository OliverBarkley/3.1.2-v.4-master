package ru.kata.spring.boot_security.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import ru.kata.spring.boot_security.demo.model.Role;
import ru.kata.spring.boot_security.demo.model.User;
import ru.kata.spring.boot_security.demo.service.UserService;
import ru.kata.spring.boot_security.demo.service.roleService.RoleService;

import javax.annotation.PostConstruct;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Controller

public class AdminController {

    private final UserService userService;

    private final RoleService roleService;

    @Autowired
    public AdminController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @GetMapping(value = "admin")
    public String index(Model model) {
        model.addAttribute("listUsers", userService.findAll());
        return "admin";
    }

    @GetMapping("/{id}")
    public String show(@PathVariable("id") int id, Model model) {
        model.addAttribute("user", userService.findById(id));
        return "show";
    }

    @GetMapping("/admin/new")
    public String newUser(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "new";
    }

    @PostMapping(value = "admin/new")
    public String create(@ModelAttribute("user")  User user, @RequestParam(required = false) String roleAdmin,
                         @RequestParam(required = false) String roleUser) {
        Collection<Role> roles = new HashSet<>();
        if (roleAdmin != null && roleAdmin.equals("ROLE_ADMIN")){
            roles.add(roleService.getRoleByName("ROLE_ADMIN"));
        } if (roleUser !=null && roleUser.equals("ROLE_USER")){
            roles.add(roleService.getRoleByName("ROLE_USER"));
        }
        user.setRoles(roles);
        userService.save(user);
        return "redirect:/admin";
    }

    @GetMapping(value = "admin/edit/{id}")
    public String editUser(ModelMap model, @PathVariable("id") long id) {
        User user = userService.findById(id);
       Collection<Role> roles = user.getRoles();
        for (Role role: roles) {
            if (role.equals(roleService.getRoleByName("ROLE_ADMIN"))) {
                model.addAttribute("roleAdmin", true);
            } if (role.equals(roleService.getRoleByName("ROLE_USER"))){
                model.addAttribute("roleUser", true);
            }

        }
        model.addAttribute("user", user);
        return "edit";
    }

    @PostMapping(value = "admin/edit")
    public String update(@ModelAttribute("user") User user, @RequestParam(required=false) String roleAdmin,
                         @RequestParam(required=false) String roleUser) {
        Collection<Role> roles = new HashSet<>();
        if (roleAdmin != null && roleAdmin .equals("ROLE_ADMIN")) {
            roles.add(roleService.getRoleByName("ROLE_ADMIN"));
        } if (roleUser != null && roleUser.equals("ROLE_USER")){
            roles.add(roleService.getRoleByName("ROLE_USER"));
        }
        user.setRoles(roles);
        userService.update(user);
        return "redirect:/admin";
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable("id") long id) {
        userService.delete(id);
        return "redirect:/admin";
    }
}
